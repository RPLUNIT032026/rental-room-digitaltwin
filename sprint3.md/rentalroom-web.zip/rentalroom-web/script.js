/* ===== Ikon (gaya feather) ===== */
const I={home:"M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z M9 22V12h6v10",grid:"M3 3h7v7H3z M14 3h7v7h-7z M14 14h7v7h-7z M3 14h7v7H3z",activity:"M22 12h-4l-3 9L9 3l-3 9H2",sliders:"M4 21v-7 M4 10V3 M12 21v-9 M12 8V3 M20 21v-5 M20 12V3 M1 14h6 M9 8h6 M17 16h6",info:"M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z M12 16v-4 M12 8h.01",user:"M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2 M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z",lock:"M5 11h14v10H5z M7 11V7a5 5 0 0 1 10 0v4",eye:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z",bell:"M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9 M13.7 21a2 2 0 0 1-3.4 0",logout:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4 M16 17l5-5-5-5 M21 12H9",check:"M20 6L9 17l-5-5",arrow:"M5 12h14 M12 5l7 7-7 7",wifi:"M5 12.55a11 11 0 0 1 14 0 M1.4 9a16 16 0 0 1 21.2 0 M8.5 16.1a6 6 0 0 1 7 0 M12 20h.01",bulb:"M9 18h6 M10 22h4 M12 2a7 7 0 0 0-4 12.7V17h8v-2.3A7 7 0 0 0 12 2z",thermo:"M14 14.76V3.5a2.5 2.5 0 0 0-5 0v11.26a4.5 4.5 0 1 0 5 0z",drop:"M12 2.7l5.7 5.6a8 8 0 1 1-11.4 0z",door:"M4 22V3h12v19 M2 22h20 M12 12h.01",snow:"M2 6h20v8H2z M6 18v3 M12 18v3 M18 18v3",expand:"M15 3h6v6 M9 21H3v-6 M21 3l-7 7 M3 21l7-7",menu:"M3 12h18 M3 6h18 M3 18h18",moon:"M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z",sun:"M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10z M12 1v2 M12 21v2 M4.2 4.2l1.4 1.4 M18.4 18.4l1.4 1.4 M1 12h2 M21 12h2 M4.2 19.8l1.4-1.4 M18.4 5.6l1.4-1.4",power:"M18.4 6.6a9 9 0 1 1-12.8 0 M12 2v10",book:"M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5z",zap:"M13 2L3 14h9l-1 8 10-12h-9z",leaf:"M11 20A7 7 0 0 1 4 13c0-6 7-10 16-10 0 9-4 17-9 17z",bed:"M2 4v16 M2 8h18a2 2 0 0 1 2 2v10 M2 17h20 M6 8v9"};

function icons(root=document){
  root.querySelectorAll("i[data-i]").forEach(e=>{
    e.innerHTML=`<svg viewBox="0 0 24 24" width="1em" height="1em" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${I[e.dataset.i]}"/></svg>`
  })
}

/* ===== State global (simulasi) ===== */
const S={
  ac:true,
  temp:24,
  lamp:true,
  acts:[{t:"09.40 WIB",x:"Lampu dinyalakan"}]
};

const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>[...r.querySelectorAll(s)];

const now=()=>new Date().toLocaleTimeString("id-ID",{
  hour:"2-digit",
  minute:"2-digit",
  hour12:false
}).replace(":",".")+" WIB";

function log(x){
  S.acts.unshift({t:now(),x});
  S.acts=S.acts.slice(0,4)
}

/* ===== Ilustrasi kamar isometrik (SVG) ===== */
function room(){
  const on=S.lamp;

  return `<svg viewBox="0 0 400 290" class="${on?"":"room-off"}" role="img" aria-label="Ilustrasi kamar kos">
<polygon points="200,272 48,190 200,108 352,190" fill="#E6ECF8"/>
<polygon points="48,190 200,108 200,8 48,90" fill="#D4E1F7"/>
<polygon points="200,108 352,190 352,90 200,8" fill="#E2EBFA"/>
<polygon points="80,149 125,125 125,75 80,99" fill="#fff" stroke="#9DB7E8" stroke-width="3"/>
<polygon points="80,149 125,125 125,75 80,99" fill="#BBD3F7" opacity=".5"/>
<polygon points="290,158 325,177 325,97 290,78" fill="#D9A765"/><circle cx="318" cy="136" r="2.5" fill="#fff"/>
<polygon points="80,186 150,222 200,196 130,160" fill="#2563EB"/>
<polygon points="80,186 150,222 150,236 80,200" fill="#1D4FD7"/><polygon points="150,222 200,196 200,210 150,236" fill="#1E40AF"/>
<polygon points="90,184 110,194 128,185 108,175" fill="#fff"/>
<polygon points="228,208 276,232 326,206 278,182" fill="#EBD3A8"/>
<polygon points="228,208 276,232 276,238 228,214" fill="#D8BB86"/><polygon points="276,232 326,206 326,212 276,238" fill="#C9AB74"/>
<polygon points="268,200 292,212 306,204 282,192" fill="#CBD5E1"/><polygon points="282,192 306,204 306,176 282,164" fill="#94A3B8"/>
<polygon points="212,140 226,148 226,162 212,154" fill="#F7E7C6"/><ellipse cx="212" cy="140" rx="8" ry="4" fill="#2F9E5B"/><circle cx="210" cy="132" r="7" fill="#3DB26B"/>
<line x1="200" y1="8" x2="200" y2="46" stroke="#94A3B8" stroke-width="2"/>
${on?'<circle cx="200" cy="56" r="34" fill="#FFE27A" opacity=".35"/>':""}
<path d="M188 56a12 12 0 0 1 24 0z" fill="${on?"#F5B301":"#94A3B8"}"/>
</svg>`
}

/* ===== Grafik garis manual (SVG) ===== */
function chart(el,data,color,min,max,unit){
  const W=420,H=190,L=34,B=28,T=10,R=10;
  const lab=["06.00","07.00","07.30","08.00","08.30","09.00"];

  const x=i=>L+i*(W-L-R)/(data.length-1);
  const y=v=>T+(1-(v-min)/(max-min))*(H-T-B);

  const pts=data.map((v,i)=>[x(i),y(v)]);
  const line=pts.map(p=>p.join(",")).join(" ");

  let g="";

  for(let k=0;k<=4;k++){
    const v=min+k*(max-min)/4;
    const yy=y(v);

    g+=`<line x1="${L}" x2="${W-R}" y1="${yy}" y2="${yy}" stroke="#EEF1F5"/><text x="${L-6}" y="${yy+3}" font-size="9" fill="#94A3B8" text-anchor="end">${Math.round(v)}</text>`
  }

  const t=lab.map((l,i)=>
    `<text x="${x(i)}" y="${H-8}" font-size="9" fill="#94A3B8" text-anchor="middle">${l}</text>`
  ).join("");

  el.innerHTML=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Grafik tren"><text x="${L}" y="8" font-size="8" fill="#94A3B8">${unit}</text>${g}<polygon points="${x(0)},${y(min)} ${line} ${x(data.length-1)},${y(min)}" fill="${color}" opacity=".12"/><polyline points="${line}" fill="none" stroke="${color}" stroke-width="1.8"/>${pts.map(p=>`<circle cx="${p[0]}" cy="${p[1]}" r="3" fill="#fff" stroke="${color}" stroke-width="1.6"/>`).join("")}${t}</svg>`
}

/* ===== Render sinkron semua tampilan ===== */
function render(){
  $$(".room-slot").forEach(e=>e.innerHTML=room());

  $$("[data-temp]").forEach(e=>e.textContent=S.temp);

  $$(".tg").forEach(b=>{
    const on=S[b.dataset.t];
    b.classList.toggle("on",on);
    b.setAttribute("aria-checked",on)
  });

  $$("[data-acbig]").forEach(e=>e.classList.toggle("dim",!S.ac));

  $$("[data-acmode]").forEach(e=>
    e.textContent=S.ac?"ON · Mode sejuk":"OFF · AC mati"
  );

  $$("[data-lamptxt]").forEach(e=>
    e.textContent=S.lamp?"Menyala":"Mati"
  );

  $$("[data-lampsub]").forEach(e=>
    e.textContent=S.lamp?"ON · Lampu utama":"OFF · Lampu utama"
  );

  $$("[data-lampchip]").forEach(e=>
    e.textContent=S.lamp?"Lampu menyala":"Lampu mati"
  );

  $("#bulb").classList.toggle("off",!S.lamp);

  $("#actList").innerHTML=S.acts.map(a=>
    `<div class="act"><i data-i="bulb"></i><div><b>${a.x}</b><div class="mut">Hari ini · ${a.t}</div></div></div>`
  ).join("");

  icons();
}

/* ===== Interaksi perangkat ===== */
document.addEventListener("click",e=>{
  const tg=e.target.closest(".tg");

  if(tg){
    const k=tg.dataset.t;
    S[k]=!S[k];

    log(k==="ac"?
      (S.ac?"AC dinyalakan":"AC dimatikan"):
      (S.lamp?"Lampu dinyalakan":"Lampu dimatikan")
    );

    render();
    return
  }

  const d=e.target.closest("[data-d]");

  if(d){
    const n=Math.min(30,Math.max(16,S.temp+ +d.dataset.d));

    if(n!==S.temp){
      S.temp=n;
      log("Suhu AC diatur ke "+n+"°C");
      render()
    }

    return
  }

  const go=e.target.closest("[data-go]");

  if(go){
    page(go.dataset.go)
  }
});

/* ===== Navigasi halaman ===== */
function page(n){
  ["dashboard","monitoring","kontrol","tentang"].forEach(p=>
    $("#pg-"+p).classList.toggle("hidden",p!==n)
  );

  $$(".nav[data-go]").forEach(b=>
    b.classList.toggle("on",b.dataset.go===n)
  );

  $("#side").classList.remove("open");
  scrollTo(0,0);

  if(n==="monitoring"){
    chart($("#ch1"),[27,27.5,28,28.5,28,28.3],"#2563EB",24,32,"Suhu (°C)");
    chart($("#ch2"),[63,64,65,64,65,66],"#16A34A",40,80,"Kelembapan (%)")
  }
}

$("#burger").onclick=()=>
  $("#side").classList.toggle("open");

/* ===== Login ===== */
function loginState(fail){
  $("#pf").classList.toggle("err",fail);
  $("#pErr").classList.toggle("hidden",!fail);
  $("#pHint").classList.toggle("hidden",fail);

  $("#loginBtn span").textContent=fail?"Coba lagi":"Login";
  $("#simFail").textContent=fail?"Kembali ke login":"Simulasikan login gagal";
}

let failed=false;

$("#simFail").onclick=()=>{
  failed=!failed;

  if(failed){
    $("#p").value="acep";
  }else{
    $("#p").value="acep123"
  }

  loginState(failed)
};

$("#eye").onclick=()=>{
  const p=$("#p");
  p.type=p.type==="password"?"text":"password"
};

$("#loginForm").onsubmit=e=>{
  e.preventDefault();

  if($("#u").value.trim()==="acep"&&$("#p").value==="acep123"){
    failed=false;
    loginState(false);
    $("#login").classList.add("hidden");
    $("#app").classList.remove("hidden");
    page("dashboard")
  }else{
    failed=true;
    loginState(true)
  }
};

$("#logout").onclick=()=>{
  $("#app").classList.add("hidden");
  $("#login").classList.remove("hidden");
  $("#u").value="acep";
  $("#p").value="acep123";
  loginState(false);
  failed=false
};

/* ===== Jam real-time ===== */
function tick(){
  const d=new Date();

  $("#cd").textContent=d.toLocaleDateString("id-ID",{
    weekday:"long",
    day:"numeric",
    month:"long",
    year:"numeric"
  });

  $("#ct").textContent=d.toLocaleTimeString("id-ID",{
    hour:"2-digit",
    minute:"2-digit",
    hour12:false
  }).replace(":",".")+" WIB"
}

tick();
setInterval(tick,1000);
render();

/* ===== FITUR TAMBAHAN ===== */
let unread=0;

function toast(m){
  const t=$("#toast");
  t.textContent=m;
  t.classList.add("show");
  clearTimeout(toast.h);
  toast.h=setTimeout(()=>
    t.classList.remove("show"),2200)
}

const _log=log;

log=function(x){
  _log(x);
  toast(x);
  unread++;
  $("#bdot").classList.remove("hidden")
};

const _render=render;

render=function(){
  _render();

  const w=(S.ac?Math.round(900-(S.temp-16)*35):0)+(S.lamp?12:0);

  $("#watt").textContent=w;
  $("#ebar").style.width=Math.min(100,w/9.1)+"%";

  $("#ebar").style.background=
    w>700?"var(--red)":
    w>400?"var(--yellow)":
    "var(--green)";

  $("#etip").textContent=
    !S.ac?"AC mati. Pemakaian listrik sangat rendah.":
    S.temp<24?"Suhu cukup dingin. Naikkan 1°C untuk menghemat energi.":
    S.temp>=27?"Pemakaian hemat. Pertahankan suhu ini.":
    "Pemakaian wajar untuk kenyamanan.";

  $("#notif").innerHTML="<b>Notifikasi</b>"+S.acts.map(a=>
    `<div class="act"><i data-i="bulb"></i><div><b>${a.x}</b><div class="mut">${a.t}</div></div></div>`
  ).join("");

  icons($("#notif"))
};

/* Mode cepat */
const SC={
  tidur:{
    ac:true,
    temp:26,
    lamp:false,
    m:"Mode tidur aktif. Selamat beristirahat."
  },
  belajar:{
    ac:true,
    temp:24,
    lamp:true,
    m:"Mode belajar aktif. Semangat!"
  },
  hemat:{
    ac:true,
    temp:28,
    lamp:true,
    m:"Mode hemat aktif."
  },
  keluar:{
    ac:false,
    temp:S.temp,
    lamp:false,
    m:"Semua perangkat dimatikan. Hati-hati di jalan."
  }
};

document.addEventListener("click",e=>{
  const b=e.target.closest("[data-scene]");
  if(!b)return;

  const c=SC[b.dataset.scene];

  S.ac=c.ac;
  S.lamp=c.lamp;

  if(c.ac)S.temp=c.temp;

  log(c.m);
  render()
});

/* Lonceng & tema */
$("#bell").onclick=e=>{
  e.stopPropagation();
  $("#notif").classList.toggle("hidden");
  unread=0;
  $("#bdot").classList.add("hidden")
};

document.addEventListener("click",e=>{
  if(!e.target.closest("#notif"))
    $("#notif").classList.add("hidden")
});

function setTheme(d){
  document.documentElement.dataset.theme=d?"dark":"light";
  $("#theme").innerHTML=`<i data-i="${d?"sun":"moon"}"></i>`;
  icons($("#theme"))
}

$("#theme").onclick=()=>
  setTheme(document.documentElement.dataset.theme!=="dark");

/* Sambutan penghuni */
function showWelcome(){
  try{
    if(localStorage.getItem("wskip")===new Date().toDateString())return
  }catch(e){}

  const h=new Date().getHours();

  $("#wgreet").textContent=
    (h<11?"SELAMAT PAGI":
    h<15?"SELAMAT SIANG":
    h<18?"SELAMAT SORE":
    "SELAMAT MALAM")+", ACEP";

  $("#welcome").classList.remove("hidden");
  $("#wgo").focus()
}

$("#wgo").onclick=()=>{
  try{
    if($("#wskip").checked)
      localStorage.setItem("wskip",new Date().toDateString())
  }catch(e){}

  $("#welcome").classList.add("hidden");
  toast("Selamat menikmati kamar Anda!")
};

document.addEventListener("keydown",e=>{
  if(e.key==="Escape")
    $("#welcome").classList.add("hidden")
});

$("#loginForm").addEventListener("submit",()=>{
  if(!$("#app").classList.contains("hidden"))
    showWelcome()
});

icons();
render();